const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const GOOGLE_MAPS_API_KEY = process.env.GOOGLE_MAPS_API_KEY;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/route", async (req, res) => {
  try {
    const { origin, destination } = req.body || {};
    if (!origin || !destination) {
      return res.status(400).json({ error: "Χρειάζονται παραλαβή και παράδοση." });
    }
    if (!GOOGLE_MAPS_API_KEY) {
      return res.status(500).json({
        error: "Δεν έχει ρυθμιστεί το GOOGLE_MAPS_API_KEY στον server."
      });
    }

    const response = await fetch(
      "https://routes.googleapis.com/directions/v2:computeRoutes",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Goog-Api-Key": GOOGLE_MAPS_API_KEY,
          "X-Goog-FieldMask":
            "routes.duration,routes.distanceMeters,routes.polyline.encodedPolyline"
        },
        body: JSON.stringify({
          origin: { address: origin },
          destination: { address: destination },
          travelMode: "TWO_WHEELER",
          routingPreference: "TRAFFIC_AWARE"
        })
      }
    );

    const data = await response.json();

    if (!response.ok || !data.routes?.length) {
      return res.status(response.status || 502).json({
        error: data.error?.message || "Δεν βρέθηκε διαδρομή."
      });
    }

    const route = data.routes[0];
    const distanceKm = route.distanceMeters / 1000;
    const durationSeconds = Number.parseInt(String(route.duration || "0").replace("s", ""), 10);
    const durationMinutes = Math.ceil(durationSeconds / 60);

    res.json({
      distanceKm: Number(distanceKm.toFixed(1)),
      durationMinutes,
      polyline: route.polyline?.encodedPolyline || null
    });
  } catch (err) {
    res.status(500).json({ error: "Σφάλμα σύνδεσης με Google Routes API." });
  }
});

app.listen(PORT, () => {
  console.log(`FASTEX Calculator V1 running on http://localhost:${PORT}`);
});
